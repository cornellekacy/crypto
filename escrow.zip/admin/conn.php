<?php $link = mysqli_connect("localhost", "root", "", "escrow-giant"); ?>
